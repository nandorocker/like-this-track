# Like This for Spotify

## Description

A simple small script to like the currently playing song on Spotify.

## Installation
After installing, using the terminal run:

```
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
````